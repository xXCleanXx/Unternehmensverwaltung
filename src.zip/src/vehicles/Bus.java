package vehicles;

@SuppressWarnings("unused")
public class Bus extends PassengerTransport {

    public Bus(int tankSize, int amountSeats) {
        super(tankSize, amountSeats);
    }
}