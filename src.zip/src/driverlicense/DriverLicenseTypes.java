package driverlicense;

@SuppressWarnings("unused")
public enum DriverLicenseTypes {
    B,
    BE,
    C,
    CE,
    D
}