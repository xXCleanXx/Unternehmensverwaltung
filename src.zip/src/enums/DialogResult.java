package enums;

public enum DialogResult {
    SAVE,
    ABORT
}