package geometry;

@SuppressWarnings("unused")
public class Pentagram extends Polygon {
    public Pentagram(double length) {
        super(5, length);
    }
}