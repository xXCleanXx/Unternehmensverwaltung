package geometry.abstractions;

public abstract class Figure2D {
    public abstract double perimeter();
    public abstract double area();
}