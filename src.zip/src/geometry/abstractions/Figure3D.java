package geometry.abstractions;

public abstract class Figure3D {
    public abstract double volume();
    public abstract double surface();
}