package geometry;

@SuppressWarnings("unused")
public class Sechseck extends Polygon {
    public Sechseck(double length) {
        super(6, length);
    }
}